﻿Imports System.Data
Imports System.Data.OleDb
Public Class rp2
    Dim cn As OleDbConnection = Dbconnection.connection
    Private Sub rp2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New OleDbCommand("SELECT a.agent_name, p.customer_name, SUM(p.policy_amt) AS total_amount FROM agent_master a INNER JOIN policy_master p ON a.agent_code = p.agent_code GROUP BY a.agent_name, p.customer_name", cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub

End Class