﻿Public Class InsuranceInformation

    Private Sub AgentInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AgentInformationToolStripMenuItem.Click
        Dim f As New frmagent
        f.Show()
    End Sub

    Private Sub CustomerInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerInformationToolStripMenuItem.Click
        Dim f As New frmpolicy
        f.Show()
    End Sub

    Private Sub PolicyAmontWiseAscendingOrderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PolicyAmontWiseAscendingOrderToolStripMenuItem.Click
        Dim f As New rp1
        f.Show()
    End Sub

    Private Sub AgentWiseHolderInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AgentWiseHolderInformationToolStripMenuItem.Click
        Dim f As New rp2
        f.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub
End Class
