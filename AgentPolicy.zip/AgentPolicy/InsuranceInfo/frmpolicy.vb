﻿Imports System.Data
Imports System.Data.OleDb
Public Class frmpolicy
    Dim cn As OleDbConnection = Dbconnection.connection
    Dim max As Integer
    Private Sub frmpolicy_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New OleDbCommand("Select * from Agent_Master", cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds, "agent")
        cbacode.DataSource = ds.Tables("agent")
        cbacode.DisplayMember = ds.Tables("agent").Columns(1).ToString
        cbacode.ValueMember = ds.Tables("agent").Columns(0).ToString
        max = CInt(DataGridView1.Rows.Count) - 2
        fillgrid()
    End Sub
    Dim dv As DataView
    Sub fillgrid()
        Dim cmd As New OleDbCommand("Select * from Policy_Master", cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim ds As New DataSet
        If ds.Tables.Contains("policy") Then
            ds.Tables("policy").Clear()
        End If
        da.Fill(ds, "policy")
        dv = New DataView(ds.Tables("policy"))
        DataGridView1.DataSource = ds.Tables("policy")
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        With DataGridView1.CurrentRow
            mtxtpno.Text = .Cells(0).Value.ToString
            cbacode.Text = .Cells(1).Value.ToString
            txtcnm.Text = .Cells(2).Value.ToString
            DateTimePicker1.Value = .Cells(3).Value.ToString
            DateTimePicker2.Value = .Cells(4).Value.ToString
            NumericUpDown1.Value = .Cells(5).Value.ToString
        End With
    End Sub

    Private Sub btnins_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnins.Click
        Dim cmd As New OleDbCommand("Insert into Policy_Master (policy_no,agent_code,customer_name,start_date,end_date,policy_amt) values(@pno,@ac,@cnm,@sdate,@edate,@pamt)", cn)
        cmd.Parameters.Add(New OleDbParameter("@pno", CInt(mtxtpno.Text)))
        cmd.Parameters.Add(New OleDbParameter("@ac", CInt(cbacode.SelectedValue)))
        cmd.Parameters.Add(New OleDbParameter("@cnm", txtcnm.Text))
        cmd.Parameters.Add(New OleDbParameter("@sdate", CDate(DateTimePicker1.Value)))
        cmd.Parameters.Add(New OleDbParameter("@edate", CDate(DateTimePicker2.Value)))
        cmd.Parameters.Add(New OleDbParameter("@pamt", CInt(NumericUpDown1.Value)))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Inserted.")
        fillgrid()
    End Sub


    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim cmd As New OleDbCommand("Update Policy_Master set customer_name = @cnm,start_date = @sdate,end_date = @edate,policy_amt = @pamt where policy_no = @pno", cn)
        cmd.Parameters.Add(New OleDbParameter("@cnm", txtcnm.Text))
        cmd.Parameters.Add(New OleDbParameter("@sdate", CDate(DateTimePicker1.Value)))
        cmd.Parameters.Add(New OleDbParameter("@edate", CDate(DateTimePicker2.Value)))
        cmd.Parameters.Add(New OleDbParameter("@pamt", CInt(NumericUpDown1.Value)))
        cmd.Parameters.Add(New OleDbParameter("@pno", CInt(mtxtpno.Text)))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Updated.")
        fillgrid()
    End Sub

    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        Dim cmd As New OleDbCommand("Delete * from Policy_Master where policy_no = @pno", cn)
        cmd.Parameters.Add(New OleDbParameter("@pno", CInt(mtxtpno.Text)))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Deleted.")
        fillgrid()
    End Sub
End Class