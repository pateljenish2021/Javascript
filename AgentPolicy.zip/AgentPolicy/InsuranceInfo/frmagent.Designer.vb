﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmagent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.mtxtacode = New System.Windows.Forms.MaskedTextBox()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.cbcity = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btninsert = New System.Windows.Forms.Button()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.btndel = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.DbagentpolicyDataSet = New InsuranceInfo.dbagentpolicyDataSet()
        Me.AgentMasterBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Agent_MasterTableAdapter = New InsuranceInfo.dbagentpolicyDataSetTableAdapters.Agent_MasterTableAdapter()
        Me.AgentcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AgentnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbagentpolicyDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AgentMasterBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Agent_code"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 29)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "City"
        '
        'mtxtacode
        '
        Me.mtxtacode.Location = New System.Drawing.Point(188, 22)
        Me.mtxtacode.Name = "mtxtacode"
        Me.mtxtacode.Size = New System.Drawing.Size(151, 35)
        Me.mtxtacode.TabIndex = 3
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(188, 98)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(151, 35)
        Me.txtname.TabIndex = 4
        '
        'cbcity
        '
        Me.cbcity.FormattingEnabled = True
        Me.cbcity.Items.AddRange(New Object() {"Surat", "Ahemdabad", "Valsad", "Navsari"})
        Me.cbcity.Location = New System.Drawing.Point(188, 166)
        Me.cbcity.Name = "cbcity"
        Me.cbcity.Size = New System.Drawing.Size(151, 37)
        Me.cbcity.TabIndex = 5
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AgentcodeDataGridViewTextBoxColumn, Me.AgentnameDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.AgentMasterBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(544, 25)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(318, 182)
        Me.DataGridView1.TabIndex = 6
        '
        'btninsert
        '
        Me.btninsert.Location = New System.Drawing.Point(394, 25)
        Me.btninsert.Name = "btninsert"
        Me.btninsert.Size = New System.Drawing.Size(119, 41)
        Me.btninsert.TabIndex = 7
        Me.btninsert.Text = "Insert"
        Me.btninsert.UseVisualStyleBackColor = True
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(394, 72)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(119, 41)
        Me.btnupdate.TabIndex = 8
        Me.btnupdate.Text = "Update"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btndel
        '
        Me.btndel.Location = New System.Drawing.Point(394, 119)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(119, 41)
        Me.btndel.TabIndex = 9
        Me.btndel.Text = "Delete"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(394, 166)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(119, 41)
        Me.btnclear.TabIndex = 10
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'DbagentpolicyDataSet
        '
        Me.DbagentpolicyDataSet.DataSetName = "dbagentpolicyDataSet"
        Me.DbagentpolicyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AgentMasterBindingSource
        '
        Me.AgentMasterBindingSource.DataMember = "Agent_Master"
        Me.AgentMasterBindingSource.DataSource = Me.DbagentpolicyDataSet
        '
        'Agent_MasterTableAdapter
        '
        Me.Agent_MasterTableAdapter.ClearBeforeFill = True
        '
        'AgentcodeDataGridViewTextBoxColumn
        '
        Me.AgentcodeDataGridViewTextBoxColumn.DataPropertyName = "agent_code"
        Me.AgentcodeDataGridViewTextBoxColumn.HeaderText = "agent_code"
        Me.AgentcodeDataGridViewTextBoxColumn.Name = "AgentcodeDataGridViewTextBoxColumn"
        '
        'AgentnameDataGridViewTextBoxColumn
        '
        Me.AgentnameDataGridViewTextBoxColumn.DataPropertyName = "agent_name"
        Me.AgentnameDataGridViewTextBoxColumn.HeaderText = "agent_name"
        Me.AgentnameDataGridViewTextBoxColumn.Name = "AgentnameDataGridViewTextBoxColumn"
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        '
        'frmagent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 340)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.btninsert)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.cbcity)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.mtxtacode)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "frmagent"
        Me.Text = "frmagent"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbagentpolicyDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AgentMasterBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents mtxtacode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents cbcity As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btninsert As System.Windows.Forms.Button
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents DbagentpolicyDataSet As InsuranceInfo.dbagentpolicyDataSet
    Friend WithEvents AgentMasterBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Agent_MasterTableAdapter As InsuranceInfo.dbagentpolicyDataSetTableAdapters.Agent_MasterTableAdapter
    Friend WithEvents AgentcodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AgentnameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
