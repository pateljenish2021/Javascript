﻿Imports System.Data
Imports System.Data.OleDb
Public Class frmagent
    Dim cn As OleDbConnection = Dbconnection.connection
    Private Sub frmagent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbagentpolicyDataSet.Agent_Master' table. You can move, or remove it, as needed.
        Me.Agent_MasterTableAdapter.Fill(Me.DbagentpolicyDataSet.Agent_Master)
        populategrid()
    End Sub

    Sub populategrid()
        Dim cmd As New OleDbCommand("Select * from Agent_Master", cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds, "agent")
        DataGridView1.DataSource = ds.Tables("agent")
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        Dim cmd As New OleDbCommand("Insert into Agent_Master(agent_code,agent_name,city) Values (@ac,@nm , @city)", cn)
        cmd.Parameters.Add(New OleDbParameter("@ac", CInt(mtxtacode.Text)))
        cmd.Parameters.Add(New OleDbParameter("@nm", txtname.Text))
        cmd.Parameters.Add(New OleDbParameter("@city", cbcity.Text))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Inserted")
        populategrid()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        With DataGridView1.CurrentRow
            mtxtacode.Text = .Cells(0).Value.ToString
            txtname.Text = .Cells(1).Value.ToString
            cbcity.Text = .Cells(2).Value.ToString
        End With
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim cmd As New OleDbCommand("Update Agent_Master set agent_name = @nm , city = @city where agent_code = @ac", cn)
        cmd.Parameters.Add(New OleDbParameter("@nm", txtname.Text))
        cmd.Parameters.Add(New OleDbParameter("@city", cbcity.Text))
        cmd.Parameters.Add(New OleDbParameter("@ac", CInt(mtxtacode.Text)))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Updated.")
        populategrid()
    End Sub

    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        Dim cmd As New OleDbCommand("delete from Agent_Master where agent_code = @ac", cn)
        cmd.Parameters.Add(New OleDbParameter("@ac", CInt(mtxtacode.Text)))
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
        MessageBox.Show("Record Deleted.")
        populategrid()
    End Sub

    Private Sub btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear.Click
        mtxtacode.Clear()
        txtname.Clear()
    End Sub
End Class