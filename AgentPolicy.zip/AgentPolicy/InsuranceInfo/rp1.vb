﻿Imports System.Data
Imports System.Data.OleDb

Public Class rp1
    Dim cn As OleDbConnection = Dbconnection.connection
    Private Sub rp1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New OleDbCommand("Select policy_no,agent_code,customer_name,policy_amt from Policy_Master order by policy_amt", cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub
End Class