﻿Imports System.Data.OleDb
Module Dbconnection
    Function connection() As OleDbConnection
        Dim cn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\Bansari\vb.net\AgentPolicy\InsuranceInfo\dbagentpolicy.accdb")
        Return cn
    End Function
End Module
